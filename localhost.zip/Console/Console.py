import requests, re, time, getpass, os

def main():    
    url = 'http://api.auth.org/index.php'
    print('Connection to: ' + url)
    username = input("Username: ")
    password = getpass.getpass("Password: ")
        
    def auth():
        result = requests.post(url, data={'user_login': username, 'user_password': password})
        return result.text
        
    authorization = auth()

    if( authorization == '{"Authorization":"Wellcome, '+username+'!"}' ):
        print('Write "!help" for get instructions.');   
        while( authorization == '{"Authorization":"Wellcome, '+username+'!"}' ):
            shell = input(username+"@")
            shell_result = requests.post(url, data={'user_login': username, 'user_password': password, 'shell': shell})
            quite = shell_result.text
            print(quite)
            
            result = quite.find('{"Authorization":"Disconnect..."}')

            if (quite.find('{"Authorization":"Disconnect..."}') != -1):
                print ("Disconnect...")
                #exit(0)
                del authorization
                main()
            else:
                print ("")

            if (quite.find('{"Authorization":"Accept denied!","Your access token":null}') != -1):
                print ("Your token has been removed!") 
                exit(0)
            else:
                print ("") 
            if (quite.find('{cls}') != -1):
                os.system('cls')
            else:
                print ("")

            if (quite.find('{exit}') != -1):
                print ("Disconnect...")
                exit(0)
            else:
                print ("")
    else:
        print(authorization)
        time.sleep(3)
        del authorization
        main()

if __name__ == "__main__":
    main()