#База данных
Создаем БД с названием "dbeach" и импортируем в неё файл "userlist.sql" ( Для тех, у кого phpMyAdmin на OpenServer'е: http://localhost/openserver/phpmyadmin/index.php )


Запускаем "Launcher.cmd", тем самым запускаем файл "Console.py" через Python
Стандартный доступ к БД: 
Пользователь: q 
Пароль: q


GET-запрос создания пользователя:
http://api.auth.org/signup.php?user_contact=temp@mail.ru&user_login=test&user_password=1234


Адрес авторизации:
http://api.auth.org/index.php


Адрес всех имеющихся пользователей:
http://api.auth.org/dashboard.php?key=0cb1f165c575889a5feac4f4ab9acc22